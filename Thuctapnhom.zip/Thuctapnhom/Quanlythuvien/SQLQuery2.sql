﻿create table DOCGIA(
	Madg nvarchar (4),
	Tendg nvarchar (30),
	Diachi nvarchar (50),
	primary key (Madg)
)
