﻿namespace Quanlythuvien
{
    partial class frmMuonTra
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmMuonTra));
            this.label2 = new System.Windows.Forms.Label();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.toolStripButton1 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton2 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton3 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton4 = new System.Windows.Forms.ToolStripButton();
            this.toolStripLabel1 = new System.Windows.Forms.ToolStripLabel();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label7 = new System.Windows.Forms.Label();
            this.txtSoluong = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.txtMasach = new System.Windows.Forms.TextBox();
            this.txtMadocgia = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.dataGridView6 = new System.Windows.Forms.DataGridView();
            this.txtNgaymuon = new System.Windows.Forms.TextBox();
            this.txtNgaytra = new System.Windows.Forms.TextBox();
            this.txtThangmuon = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.txtNammuon = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.txtThangtra = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.txtNamtra = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.txtSongaytre = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.btnThanhToan = new System.Windows.Forms.Button();
            this.label15 = new System.Windows.Forms.Label();
            this.txtTienphat = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.Madocgia = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Masach = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.NgayMuon = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Thangmuon = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Nammuon = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Ngaytra = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Thangtra = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Namtra = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Thoigianmuon = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Soluongmuon = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Tienphat = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.txtThoigianmuon = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txtTongTienPhaiTra = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.txtdatt = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.txtaa = new System.Windows.Forms.TextBox();
            this.label21 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.label22 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.toolStrip1.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView6)).BeginInit();
            this.SuspendLayout();
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Times New Roman", 20.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Blue;
            this.label2.Location = new System.Drawing.Point(107, 16);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(324, 31);
            this.label2.TabIndex = 7;
            this.label2.Text = "DANH SÁCH MƯỢN TRẢ";
            // 
            // toolStrip1
            // 
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripButton1,
            this.toolStripButton2,
            this.toolStripButton3,
            this.toolStripButton4,
            this.toolStripLabel1});
            this.toolStrip1.Location = new System.Drawing.Point(0, 0);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(1237, 25);
            this.toolStrip1.TabIndex = 10;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // toolStripButton1
            // 
            this.toolStripButton1.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton1.Image")));
            this.toolStripButton1.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton1.Name = "toolStripButton1";
            this.toolStripButton1.Size = new System.Drawing.Size(82, 22);
            this.toolStripButton1.Text = "Thêm mới";
            this.toolStripButton1.Click += new System.EventHandler(this.toolStripButton1_Click);
            // 
            // toolStripButton2
            // 
            this.toolStripButton2.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton2.Image")));
            this.toolStripButton2.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton2.Name = "toolStripButton2";
            this.toolStripButton2.Size = new System.Drawing.Size(46, 22);
            this.toolStripButton2.Text = "Sửa";
            this.toolStripButton2.Click += new System.EventHandler(this.toolStripButton2_Click);
            // 
            // toolStripButton3
            // 
            this.toolStripButton3.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton3.Image")));
            this.toolStripButton3.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton3.Name = "toolStripButton3";
            this.toolStripButton3.Size = new System.Drawing.Size(47, 22);
            this.toolStripButton3.Text = "Xóa";
            this.toolStripButton3.Click += new System.EventHandler(this.toolStripButton3_Click);
            // 
            // toolStripButton4
            // 
            this.toolStripButton4.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton4.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton4.Image")));
            this.toolStripButton4.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton4.Name = "toolStripButton4";
            this.toolStripButton4.Size = new System.Drawing.Size(23, 22);
            this.toolStripButton4.Text = "toolStripButton4";
            this.toolStripButton4.Click += new System.EventHandler(this.toolStripButton4_Click);
            // 
            // toolStripLabel1
            // 
            this.toolStripLabel1.Name = "toolStripLabel1";
            this.toolStripLabel1.Size = new System.Drawing.Size(38, 22);
            this.toolStripLabel1.Text = "Thoát";
            this.toolStripLabel1.Click += new System.EventHandler(this.toolStripLabel1_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.groupBox1.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.groupBox1.Controls.Add(this.label22);
            this.groupBox1.Controls.Add(this.label23);
            this.groupBox1.Controls.Add(this.txtdatt);
            this.groupBox1.Controls.Add(this.label20);
            this.groupBox1.Controls.Add(this.txtaa);
            this.groupBox1.Controls.Add(this.label21);
            this.groupBox1.Controls.Add(this.button1);
            this.groupBox1.Controls.Add(this.label19);
            this.groupBox1.Controls.Add(this.txtTongTienPhaiTra);
            this.groupBox1.Controls.Add(this.label16);
            this.groupBox1.Controls.Add(this.label15);
            this.groupBox1.Controls.Add(this.btnThanhToan);
            this.groupBox1.Controls.Add(this.txtSongaytre);
            this.groupBox1.Controls.Add(this.label14);
            this.groupBox1.Controls.Add(this.label13);
            this.groupBox1.Controls.Add(this.txtNamtra);
            this.groupBox1.Controls.Add(this.label12);
            this.groupBox1.Controls.Add(this.txtThangtra);
            this.groupBox1.Controls.Add(this.label11);
            this.groupBox1.Controls.Add(this.txtNammuon);
            this.groupBox1.Controls.Add(this.label10);
            this.groupBox1.Controls.Add(this.txtThangmuon);
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Controls.Add(this.txtNgaytra);
            this.groupBox1.Controls.Add(this.txtNgaymuon);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.txtTienphat);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.txtSoluong);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.txtThoigianmuon);
            this.groupBox1.Controls.Add(this.txtMasach);
            this.groupBox1.Controls.Add(this.txtMadocgia);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.dataGridView6);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Location = new System.Drawing.Point(-2, 40);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(1183, 693);
            this.groupBox1.TabIndex = 11;
            this.groupBox1.TabStop = false;
            this.groupBox1.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(43, 303);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(49, 13);
            this.label7.TabIndex = 21;
            this.label7.Text = "Số lượng";
            // 
            // txtSoluong
            // 
            this.txtSoluong.Location = new System.Drawing.Point(124, 300);
            this.txtSoluong.Name = "txtSoluong";
            this.txtSoluong.Size = new System.Drawing.Size(332, 20);
            this.txtSoluong.TabIndex = 20;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(50, 199);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(47, 13);
            this.label6.TabIndex = 19;
            this.label6.Text = "Ngày trả";
            // 
            // txtMasach
            // 
            this.txtMasach.Location = new System.Drawing.Point(124, 89);
            this.txtMasach.Name = "txtMasach";
            this.txtMasach.Size = new System.Drawing.Size(332, 20);
            this.txtMasach.TabIndex = 14;
            // 
            // txtMadocgia
            // 
            this.txtMadocgia.Location = new System.Drawing.Point(124, 63);
            this.txtMadocgia.Name = "txtMadocgia";
            this.txtMadocgia.Size = new System.Drawing.Size(332, 20);
            this.txtMadocgia.TabIndex = 12;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(44, 92);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(48, 13);
            this.label4.TabIndex = 11;
            this.label4.Text = "Mã sách";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(31, 121);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(61, 13);
            this.label3.TabIndex = 10;
            this.label3.Text = "Ngày mượn";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(31, 66);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(61, 13);
            this.label1.TabIndex = 9;
            this.label1.Text = "Mã độc giả";
            // 
            // dataGridView6
            // 
            this.dataGridView6.AllowUserToAddRows = false;
            this.dataGridView6.AllowUserToDeleteRows = false;
            this.dataGridView6.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView6.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Madocgia,
            this.Masach,
            this.NgayMuon,
            this.Thangmuon,
            this.Nammuon,
            this.Ngaytra,
            this.Thangtra,
            this.Namtra,
            this.Thoigianmuon,
            this.Soluongmuon,
            this.Tienphat});
            this.dataGridView6.Location = new System.Drawing.Point(6, 368);
            this.dataGridView6.Name = "dataGridView6";
            this.dataGridView6.ReadOnly = true;
            this.dataGridView6.Size = new System.Drawing.Size(1133, 190);
            this.dataGridView6.TabIndex = 8;
            this.dataGridView6.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView6_CellClick);
            this.dataGridView6.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView6_CellContentClick);
            this.dataGridView6.Click += new System.EventHandler(this.dataGridView3_Click);
            // 
            // txtNgaymuon
            // 
            this.txtNgaymuon.Location = new System.Drawing.Point(124, 118);
            this.txtNgaymuon.Name = "txtNgaymuon";
            this.txtNgaymuon.Size = new System.Drawing.Size(332, 20);
            this.txtNgaymuon.TabIndex = 24;
            // 
            // txtNgaytra
            // 
            this.txtNgaytra.Location = new System.Drawing.Point(124, 196);
            this.txtNgaytra.Name = "txtNgaytra";
            this.txtNgaytra.Size = new System.Drawing.Size(332, 20);
            this.txtNgaytra.TabIndex = 25;
            // 
            // txtThangmuon
            // 
            this.txtThangmuon.Location = new System.Drawing.Point(124, 144);
            this.txtThangmuon.Name = "txtThangmuon";
            this.txtThangmuon.Size = new System.Drawing.Size(332, 20);
            this.txtThangmuon.TabIndex = 27;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(31, 147);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(67, 13);
            this.label9.TabIndex = 26;
            this.label9.Text = "Tháng mượn";
            // 
            // txtNammuon
            // 
            this.txtNammuon.Location = new System.Drawing.Point(124, 170);
            this.txtNammuon.Name = "txtNammuon";
            this.txtNammuon.Size = new System.Drawing.Size(332, 20);
            this.txtNammuon.TabIndex = 29;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(31, 173);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(58, 13);
            this.label10.TabIndex = 28;
            this.label10.Text = "Năm mượn";
            // 
            // txtThangtra
            // 
            this.txtThangtra.Location = new System.Drawing.Point(124, 222);
            this.txtThangtra.Name = "txtThangtra";
            this.txtThangtra.Size = new System.Drawing.Size(332, 20);
            this.txtThangtra.TabIndex = 31;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(39, 225);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(53, 13);
            this.label11.TabIndex = 30;
            this.label11.Text = "Tháng trả";
            // 
            // txtNamtra
            // 
            this.txtNamtra.Location = new System.Drawing.Point(124, 248);
            this.txtNamtra.Name = "txtNamtra";
            this.txtNamtra.Size = new System.Drawing.Size(332, 20);
            this.txtNamtra.TabIndex = 33;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(48, 248);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(44, 13);
            this.label12.TabIndex = 32;
            this.label12.Text = "Năm trả";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Times New Roman", 20.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.Color.Blue;
            this.label13.Location = new System.Drawing.Point(486, 16);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(331, 31);
            this.label13.TabIndex = 34;
            this.label13.Text = "TIỀN PHẠT(2000đ/1 ngày)";
            this.label13.Click += new System.EventHandler(this.label13_Click);
            // 
            // txtSongaytre
            // 
            this.txtSongaytre.Location = new System.Drawing.Point(592, 67);
            this.txtSongaytre.Name = "txtSongaytre";
            this.txtSongaytre.Size = new System.Drawing.Size(163, 20);
            this.txtSongaytre.TabIndex = 36;
            this.txtSongaytre.TextChanged += new System.EventHandler(this.textBox7_TextChanged);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(515, 70);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(73, 13);
            this.label14.TabIndex = 35;
            this.label14.Text = "Trễ hạn(ngày)";
            this.label14.Click += new System.EventHandler(this.label14_Click);
            // 
            // btnThanhToan
            // 
            this.btnThanhToan.Location = new System.Drawing.Point(680, 132);
            this.btnThanhToan.Name = "btnThanhToan";
            this.btnThanhToan.Size = new System.Drawing.Size(75, 32);
            this.btnThanhToan.TabIndex = 37;
            this.btnThanhToan.Text = "Thanh toán";
            this.btnThanhToan.UseVisualStyleBackColor = true;
            this.btnThanhToan.Click += new System.EventHandler(this.button1_Click);
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(761, 96);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(30, 13);
            this.label15.TabIndex = 38;
            this.label15.Text = "VNĐ";
            this.label15.Click += new System.EventHandler(this.label15_Click);
            // 
            // txtTienphat
            // 
            this.txtTienphat.Location = new System.Drawing.Point(124, 326);
            this.txtTienphat.Name = "txtTienphat";
            this.txtTienphat.Size = new System.Drawing.Size(332, 20);
            this.txtTienphat.TabIndex = 22;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(40, 329);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(52, 13);
            this.label8.TabIndex = 23;
            this.label8.Text = "Tiền phạt";
            // 
            // Madocgia
            // 
            this.Madocgia.DataPropertyName = "Madocgia";
            this.Madocgia.HeaderText = "Mã độc giả";
            this.Madocgia.Name = "Madocgia";
            this.Madocgia.ReadOnly = true;
            // 
            // Masach
            // 
            this.Masach.DataPropertyName = "Masach";
            this.Masach.HeaderText = "Mã sách";
            this.Masach.Name = "Masach";
            this.Masach.ReadOnly = true;
            // 
            // NgayMuon
            // 
            this.NgayMuon.DataPropertyName = "NgayMuon";
            this.NgayMuon.HeaderText = "Ngày mượn";
            this.NgayMuon.Name = "NgayMuon";
            this.NgayMuon.ReadOnly = true;
            // 
            // Thangmuon
            // 
            this.Thangmuon.DataPropertyName = "Thangmuon";
            this.Thangmuon.HeaderText = "Tháng mượn";
            this.Thangmuon.Name = "Thangmuon";
            this.Thangmuon.ReadOnly = true;
            // 
            // Nammuon
            // 
            this.Nammuon.DataPropertyName = "Nammuon";
            this.Nammuon.HeaderText = "Năm mượn";
            this.Nammuon.Name = "Nammuon";
            this.Nammuon.ReadOnly = true;
            // 
            // Ngaytra
            // 
            this.Ngaytra.DataPropertyName = "Ngaytra";
            this.Ngaytra.HeaderText = "Ngày trả";
            this.Ngaytra.Name = "Ngaytra";
            this.Ngaytra.ReadOnly = true;
            // 
            // Thangtra
            // 
            this.Thangtra.DataPropertyName = "Thangtra";
            this.Thangtra.HeaderText = "Tháng trả";
            this.Thangtra.Name = "Thangtra";
            this.Thangtra.ReadOnly = true;
            // 
            // Namtra
            // 
            this.Namtra.DataPropertyName = "Namtra";
            this.Namtra.HeaderText = "Năm trả";
            this.Namtra.Name = "Namtra";
            this.Namtra.ReadOnly = true;
            // 
            // Thoigianmuon
            // 
            this.Thoigianmuon.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Thoigianmuon.DataPropertyName = "Thoigianmuon";
            this.Thoigianmuon.HeaderText = "Thời gian mượn";
            this.Thoigianmuon.Name = "Thoigianmuon";
            this.Thoigianmuon.ReadOnly = true;
            // 
            // Soluongmuon
            // 
            this.Soluongmuon.DataPropertyName = "Soluongmuon";
            this.Soluongmuon.HeaderText = "Số lượng mượn";
            this.Soluongmuon.Name = "Soluongmuon";
            this.Soluongmuon.ReadOnly = true;
            // 
            // Tienphat
            // 
            this.Tienphat.DataPropertyName = "Tienphat";
            this.Tienphat.HeaderText = "Tiền phạt";
            this.Tienphat.Name = "Tienphat";
            this.Tienphat.ReadOnly = true;
            // 
            // txtThoigianmuon
            // 
            this.txtThoigianmuon.Location = new System.Drawing.Point(124, 274);
            this.txtThoigianmuon.Name = "txtThoigianmuon";
            this.txtThoigianmuon.Size = new System.Drawing.Size(332, 20);
            this.txtThoigianmuon.TabIndex = 15;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(12, 277);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(103, 13);
            this.label5.TabIndex = 16;
            this.label5.Text = "Thời gian mượn(day)";
            this.label5.Click += new System.EventHandler(this.label5_Click);
            // 
            // txtTongTienPhaiTra
            // 
            this.txtTongTienPhaiTra.Location = new System.Drawing.Point(592, 93);
            this.txtTongTienPhaiTra.Name = "txtTongTienPhaiTra";
            this.txtTongTienPhaiTra.Size = new System.Drawing.Size(163, 20);
            this.txtTongTienPhaiTra.TabIndex = 40;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(554, 96);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(32, 13);
            this.label16.TabIndex = 39;
            this.label16.Text = "Tổng";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Times New Roman", 20.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.ForeColor = System.Drawing.Color.Blue;
            this.label19.Location = new System.Drawing.Point(615, 211);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(112, 31);
            this.label19.TabIndex = 44;
            this.label19.Text = "GHI NỢ";
            // 
            // txtdatt
            // 
            this.txtdatt.Location = new System.Drawing.Point(592, 276);
            this.txtdatt.Name = "txtdatt";
            this.txtdatt.Size = new System.Drawing.Size(163, 20);
            this.txtdatt.TabIndex = 49;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(509, 280);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(79, 13);
            this.label20.TabIndex = 48;
            this.label20.Text = "Đã Thanh toán";
            // 
            // txtaa
            // 
            this.txtaa.Location = new System.Drawing.Point(592, 248);
            this.txtaa.Name = "txtaa";
            this.txtaa.Size = new System.Drawing.Size(163, 20);
            this.txtaa.TabIndex = 47;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(510, 251);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(78, 13);
            this.label21.TabIndex = 46;
            this.label21.Text = "Số tiền phải trả";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(680, 313);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 32);
            this.button1.TabIndex = 45;
            this.button1.Text = "Ghi nợ";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(761, 279);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(30, 13);
            this.label22.TabIndex = 51;
            this.label22.Text = "VNĐ";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(761, 251);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(30, 13);
            this.label23.TabIndex = 50;
            this.label23.Text = "VNĐ";
            // 
            // frmMuonTra
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1237, 749);
            this.Controls.Add(this.toolStrip1);
            this.Controls.Add(this.groupBox1);
            this.Name = "frmMuonTra";
            this.Text = "frmMuonTra";
            this.Load += new System.EventHandler(this.frmMuonTra_Load);
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView6)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripButton toolStripButton1;
        private System.Windows.Forms.ToolStripButton toolStripButton2;
        private System.Windows.Forms.ToolStripButton toolStripButton3;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox txtMasach;
        private System.Windows.Forms.TextBox txtMadocgia;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridView dataGridView6;
        private System.Windows.Forms.ToolStripButton toolStripButton4;
        private System.Windows.Forms.ToolStripLabel toolStripLabel1;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtSoluong;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtNammuon;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox txtThangmuon;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txtNgaytra;
        private System.Windows.Forms.TextBox txtNgaymuon;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox txtNamtra;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox txtThangtra;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Button btnThanhToan;
        private System.Windows.Forms.TextBox txtSongaytre;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtTienphat;
        private System.Windows.Forms.DataGridViewTextBoxColumn Madocgia;
        private System.Windows.Forms.DataGridViewTextBoxColumn Masach;
        private System.Windows.Forms.DataGridViewTextBoxColumn NgayMuon;
        private System.Windows.Forms.DataGridViewTextBoxColumn Thangmuon;
        private System.Windows.Forms.DataGridViewTextBoxColumn Nammuon;
        private System.Windows.Forms.DataGridViewTextBoxColumn Ngaytra;
        private System.Windows.Forms.DataGridViewTextBoxColumn Thangtra;
        private System.Windows.Forms.DataGridViewTextBoxColumn Namtra;
        private System.Windows.Forms.DataGridViewTextBoxColumn Thoigianmuon;
        private System.Windows.Forms.DataGridViewTextBoxColumn Soluongmuon;
        private System.Windows.Forms.DataGridViewTextBoxColumn Tienphat;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtThoigianmuon;
        private System.Windows.Forms.TextBox txtTongTienPhaiTra;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.TextBox txtdatt;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.TextBox txtaa;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label19;
    }
}