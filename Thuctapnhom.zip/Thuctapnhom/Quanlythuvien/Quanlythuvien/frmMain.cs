﻿using System;
using System.Windows.Forms;


namespace Quanlythuvien
{
    public partial class frmMain : Form
    {
        public frmMain()
        {
            InitializeComponent();
        }

        private void statusStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void toolStripStatusLabel1_Click(object sender, EventArgs e)
        {

        }

        private void thôngTinTácGiảToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Phần mềm thuộc về nhóm 4");
        }

        private void thoátToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
            Dispose();
        }

        private void đầuSáchToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmDauSach ds = new frmDauSach();
            ds.ShowDialog();
        }

        private void độcGiảToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmDocgia frmdocgia = new frmDocgia();
            frmdocgia.ShowDialog();
        }

        private void thôngTinMượnTrảToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmMuonTra MuonTra = new frmMuonTra();
            MuonTra.ShowDialog();
        }

        private void thôngTinTácGiảToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            frmTacGia tg = new frmTacGia();
            tg.ShowDialog();
        }
    }
}
