﻿create database Project_QuanlythuvienMTA
create table Docgia(
	Madocgia nvarchar(4),
	Tendocgia nvarchar (30),
	Diachi nvarchar (50),
	primary key (Madocgia)
)
create table Tacgia(
	Matacgia nvarchar(4),
	Tentacgia nvarchar (30),
	Ngaysinh date,
	QueQuan nvarchar(30),
	primary key (Matacgia)
)
create table Dausach(
	Masach nvarchar(8),
	Matacgia nvarchar(4),
	Tensach nvarchar (30),
	TenNXB nvarchar (30),
	NamXB int,
	Soluong int,
	Gia float,
	primary key (Masach),
	foreign key (Matacgia) references Tacgia (Matacgia)
)
create table Muontra(
	Madocgia nvarchar(4),
	Masach nvarchar(8),
	Ngaymuon int,
	Thangmuon int,
	Nammuon int,
	Thoigianmuon int,
	Ngaytra int,
	Thangtra int,
	Namtra int,
	Soluongmuon int,
	Tienphat float,
	foreign key (Madocgia) references Docgia (Madocgia),
	foreign key (Masach) references Dausach (Masach)
)

create table Loaisach(
	Maloaisach nvarchar (8),
	Tenloaisach nvarchar (50),
	primary key (Maloaisach)
)

insert into Docgia values ('0004',N'Nguy?n An Nam','MTA')
UPDATE Docgia SET Tendocgia = N'TTCK', Diachi = N'MTA' WHERE Madocgia = 0005;

insert into Dausach values ('0001',N'Giải tích 1',N'Nguyễn Văn Tèo','1997')
insert into Dausach values ('0002',N'Giải tích 1',N'Nguyễn Văn Tèo','1997')
insert into Dausach values ('0003',N'Giải tích 1',N'Nguyễn Văn Tèo','1997')
insert into Dausach values ('0004',N'Giải tích 1',N'Nguyễn Văn Tèo','1997')
insert into Dausach values ('0005',N'Giải tích 1',N'Nguyễn Văn Tèo','1997')
drop table Dausach
drop table Muontra
drop table Tacgia
SELECT * from Dausach
update Dausach set Tensach = N'Giải tích 1' where Masach = '0001'
SELECT * from Dausach where Masach like N'%GT%'
UPDATE Dausach set Tensach =N'Giải tích 1',TenNXB = N'MTA',NamXB=N'2017',Soluong='100',Gia='21500'  where Masach ='GT0001'

select * from Tacgia
delete from Tacgia where Matacgia = '0004'
update Tacgia set Tentacgia = N'a', Ngaysinh = '2/2/2018', QueQuan = N'MTA' where Matacgia = '0001'
insert into Tacgia values ('0005',N'Ten','3/2/2014',N'MTA')

insert into Dausach values ('masach','matacgia',N'tensach',N'tenNXB','NamXB','Soluong','gia')
	select * from Muontra

select * from Dausach where Tensach like N'%G%' 
select *from Dausach
select *from Dausach ds join Tacgia tg on ds.Matacgia = tg.Matacgia where tg.Tentacgia like N'%A%'
select *from Muontra

delete from Muontra where Madocgia = '0002'
insert into Muontra values ('0002','GT02','5','6','2018','5','11','2018','','2','0')
update Muontra set Ngaymuon = '6', Thangmuon ='7' ,Nammuon='2018',Ngaytra='6',Thangtra='10',Namtra='2018', Thoigianmuon='3',Soluongmuon='1',Tienphat='0' where Madocgia = '0001'

update Muontra set Tienphat = '' where Madocgia = ''